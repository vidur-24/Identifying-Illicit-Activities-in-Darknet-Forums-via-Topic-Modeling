README 

Myiwc.zip file contains:
README-Myiwc.txt
Myiwc.txt


Forum:	myiwc
Language:	English


Dates of Collection:	11/5/2000 - 2/19/2010
Number of Posts:	25,016
Number of Threads:	6,310
Number of Members:	756
Format:	Zip file, unzips to .txt
Size (unzipped):	53.14 MB




How to cite this dataset
Author(s): Artificial Intelligence Lab, Management Information Systems Department, University of Arizona.

Title: Myiwc Forum Dataset

Publisher: University of Arizona Artificial Intelligence Lab, AZSecure-data, Director Hsinchun Chen

Location: [AZSecure-data has not yet implemented Digital Object Identifiers or Persistent URLs, please 
copy and paste the location where you retrieve this file from within http://www.azsecure-data.org/]




This dataset is one of twenty-three forums which were collected up through 2012 by the Artificial Intelligence Lab to support its Dark Web project on the study of international Jihadi social media and movement.  Each collection contains up to millions of postings written by thousands of forum members.  Postings are organized into threads which generally indicate the topic under discussion.  Each posting includes detailed metadata such as date, member name, etc. Each forum is provided as a downloadable compressed text file which may then be opened in any CSV-compatible text processing program.
