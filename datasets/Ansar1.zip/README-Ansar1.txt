README
Ansar1.zip file contains:
README-Ansar1.txt
Ansar1.txt

Forum:	ANSAR1
Language:	English


Dates of Collection:	12/8/2008 - 1/20/2010
Number of Posts:	29,492
Number of Threads:	11,244
Number of Members:	382
Format:	Zip file, unzips to .txt
Size (unzipped):	51.74 MB


How to cite this dataset
Author(s): Artificial Intelligence Lab, Management Information Systems Department, University of Arizona.

Title: Ansar1 Forum Dataset

Publisher: University of Arizona Artificial Intelligence Lab, AZSecure-data, Director Hsinchun Chen

Location: [AZSecure-data has not yet implemented Digital Object Identifiers or Persistent URLs, please 
copy and paste the location where you retrieve this file from within http://www.azsecure-data.org/]




This dataset is one of twenty-three forums which were collected up through 2012 by the Artificial Intelligence Lab to support its Dark Web project on the study of international Jihadi social media and movement.  Each collection contains up to millions of postings written by thousands of forum members.  Postings are organized into threads which generally indicate the topic under discussion.  Each posting includes detailed metadata such as date, member name, etc. Each forum is provided as a downloadable compressed text file which may then be opened in any CSV-compatible text processing program.

